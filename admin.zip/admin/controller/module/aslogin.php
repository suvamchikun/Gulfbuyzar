<?php
class ControllerModuleASlogin extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('module/aslogin');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('aslogin', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_login'] = $this->language->get('text_login');
		$data['text_register'] = $this->language->get('text_register');
		$data['text_loginsuccess'] = $this->language->get('text_loginsuccess');
		$data['text_loginfail'] = $this->language->get('text_loginfail');
		$data['text_registersuccess'] = $this->language->get('text_registersuccess');
		$data['text_emailexist'] = $this->language->get('text_emailexist');
		$data['text_asaccount'] = $this->language->get('text_asaccount');
		$data['text_assamepage'] = $this->language->get('text_assamepage');
		$data['text_fbdisable'] = $this->language->get('text_fbdisable');
		$data['text_fbenable'] = $this->language->get('text_fbenable');
		$data['text_fbpopupmodule'] = $this->language->get('text_fbpopupmodule');
		$data['text_fbdefault'] = $this->language->get('text_fbdefault');
		

		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_redirect'] = $this->language->get('entry_redirect');
		$data['entry_fbname'] = $this->language->get('entry_fbname');
		$data['entry_gname'] = $this->language->get('entry_gname');
		$data['entry_tname'] = $this->language->get('entry_tname');
		$data['entry_fbappidname'] = $this->language->get('entry_fbappidname');
		$data['entry_fbsecretname'] = $this->language->get('entry_fbsecretname');
		$data['entry_fbstatus'] = $this->language->get('entry_fbstatus');
		$data['entry_gplusappidname'] = $this->language->get('entry_gplusappidname');
		$data['entry_gplussecretname'] = $this->language->get('entry_gplussecretname');
		$data['entry_gplusredirect'] = $this->language->get('entry_gplusredirect');
		$data['entry_emailverification'] = $this->language->get('entry_emailverification');
		$data['entry_weemail'] = $this->language->get('entry_weemail');
		$data['entry_gplusstatus'] = $this->language->get('entry_gplusstatus');
		$data['entry_proversion'] = $this->language->get('entry_proversion');
		$data['entry_emessage'] = $this->language->get('entry_emessage');
		
		$data['text_gplusdisable'] = $this->language->get('text_gplusdisable');
		$data['text_gplusenable'] = $this->language->get('text_gplusenable');
		
		$data['tab_general'] = $this->language->get('tab_general');
		$data['tab_facebookdata'] = $this->language->get('tab_facebookdata');
		$data['tab_gplusdata'] = $this->language->get('tab_gplusdata');
		$data['tab_email'] = $this->language->get('tab_email');
		$data['tab_popupset'] = $this->language->get('tab_popupset');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('module/aslogin', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['action'] = $this->url->link('module/aslogin', 'token=' . $this->session->data['token'], 'SSL');

		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		if (isset($this->request->post['aslogin_status'])) {
			$data['aslogin_status'] = $this->request->post['aslogin_status'];
		} else {
			$data['aslogin_status'] = $this->config->get('aslogin_status');
		}
		
		if (isset($this->request->post['aslogin_weemail'])) {
			$data['aslogin_weemail'] = $this->request->post['aslogin_weemail'];
		} else {
			$data['aslogin_weemail'] = $this->config->get('aslogin_weemail');
		}
		
		if (isset($this->request->post['aslogin_gname'])) {
			$data['aslogin_gname'] = $this->request->post['aslogin_gname'];
		} else {
			$data['aslogin_gname'] = $this->config->get('aslogin_gname');
		}
		
		if (isset($this->request->post['aslogin_tname'])) {
			$data['aslogin_tname'] = $this->request->post['aslogin_tname'];
		} else {
			$data['aslogin_tname'] = $this->config->get('aslogin_tname');
		}
		
		if (isset($this->request->post['aslogin_fbname'])) {
			$data['aslogin_fbname'] = $this->request->post['aslogin_fbname'];
		} else {
			$data['aslogin_fbname'] = $this->config->get('aslogin_fbname');
		}
		
		if (isset($this->request->post['aslogin_emailmesssage'])) {
			$data['aslogin_emailmesssage'] = $this->request->post['aslogin_emailmesssage'];
		} else {
			$data['aslogin_emailmesssage'] = $this->config->get('aslogin_emailmesssage');
		}
		
		if (isset($this->request->post['aslogin_redirect'])) {
			$data['aslogin_redirect'] = $this->request->post['aslogin_redirect'];
		} else {
			$data['aslogin_redirect'] = $this->config->get('aslogin_redirect');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/aslogin.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/aslogin')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}