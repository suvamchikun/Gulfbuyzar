<?php

// Tex
$_['text_footer'] = ' دعم <a href="http://www.opencart.com" target="_blank">Paxanova Solutions</a> &copy; 2016 - ' . date('Y') . ' جميع الحقوق محفوظة%s';
$_['text_version'] 	= 'Version %s';