<?php
// Text
$_['text_footer'] 	= '<a href="http://www.paxanova.com">Paxanova Solutions</a> &copy; 2016-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] 	= 'Version %s';