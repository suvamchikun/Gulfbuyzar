<?php
class ControllerModuleASlogin extends Controller {
	private $error = array();
	
    public function registerform() {
        $this->load->language('module/aslogin');
        $this->load->model('module/aslogin');
		
        $data['text_login'] = $this->language->get('text_login');
        $data['text_register'] = $this->language->get('text_register');
        $data['text_name'] = $this->language->get('text_name');
        $data['text_lname'] = $this->language->get('text_lname');
        $data['text_password'] = $this->language->get('text_password');
        $data['text_cfpassword'] = $this->language->get('text_cfpassword');
        $data['text_email'] = $this->language->get('text_email');
        $data['text_signup'] = $this->language->get('text_signup');
        
        $data['login'] = $this->url->link('module/aslogin/loginform', '', 'SSL');
        $data['register'] = $this->url->link('module/aslogin/registerform', '', 'SSL');
		
		$data['asloginformlayout'] = 1;
		$data['code'] = 'aslogin';
		$data['key'] = 'aslogin_status';
		
		$mstatuscheck = $this->model_module_aslogin->checkModuleStatus($data);
		
		$this->response->setOutput($this->load->view('module/aslogin', $data));
        
    }
	
	public function register() {
		$this->load->language('module/aslogin');
		$this->load->model('module/aslogin');
		$this->load->model('setting/setting');
        
        $data['text_success'] = $this->language->get('text_success');
		$data['text_exist'] = $this->language->get('text_exist');
		
		//**********************Get aslogin Setting**************************************
		$code = 'aslogin';
		$msetting = $this->model_setting_setting->getSetting($code);
		//*******************Get aslogin Setting End*************************************
		$data['weemail'] = $msetting['aslogin_weemail'];
		$data['emessgae'] = $msetting['aslogin_emailmesssage'];
		$data['twitter'] = $msetting['aslogin_tname'];
		$data['facebook'] = $msetting['aslogin_fbname'];
		$data['googleplus'] = $msetting['aslogin_gname'];
		
        if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} else {
			$data['name'] = '';
		}
        
        if (isset($this->request->post['lname'])) {
			$data['lname'] = $this->request->post['lname'];
		} else {
			$data['lname'] = '';
		}
        
        if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} else {
			$data['email'] = '';
		}
        
        if (isset($this->request->post['password'])) {
			$data['password'] = $this->request->post['password'];
		} else {
			$data['password'] = '';
		}
        
        if (isset($this->request->post['cfpassword'])) {
			$data['cfpassword'] = $this->request->post['cfpassword'];
		} else {
			$data['cfpassword'] = '';
		}
		
		$emailcheck = $this->model_module_aslogin->checkEmailid($data);
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if ($emailcheck) {	
				echo('<span class="success">'.$data['text_exist'].'</span>');
			} else {
                                $getlogo = $this->model_setting_setting->getSetting($code = 'config');
				
				$data['logo'] = $getlogo['config_logo'];

				$this->model_module_aslogin->addCustomer($data);		
				echo('<span class="success">'.$data['text_success'].'</span>');
			}	
		}

		if (isset($this->error['name'])) {
			echo('<span class="success">'.$data['error_name'] = $this->error['name'].'</span>');
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['lname'])) {
			echo('<span class="success">'.$data['error_lname'] = $this->error['lname'].'</span>');
		} else {
			$data['error_lname'] = '';
		}

		if (isset($this->error['email'])) {
			echo('<span class="success">'.$data['error_email'] = $this->error['email'].'</span>');
		} else {
			$data['error_email'] = '';
		}

		if (isset($this->error['password'])) {
			//echo($data['error_password'] = $this->error['password']);
			echo('<span class="success">'.$data['error_password'] = $this->error['password'].'</span>');
		} else {
			$data['error_password'] = '';
		}
    }
	
	public function validate() {
		if ((utf8_strlen(trim($this->request->post['name'])) < 1) || (utf8_strlen(trim($this->request->post['name'])) > 32)) {
			$this->error['firstname'] = $this->language->get('error_firstname');
		}

		if ((utf8_strlen(trim($this->request->post['lname'])) < 1) || (utf8_strlen(trim($this->request->post['lname'])) > 32)) {
			$this->error['lname'] = $this->language->get('error_lname');
		}

		if ((utf8_strlen($this->request->post['email']) > 96) || !preg_match('/^[^\@]+@.*.[a-z]{2,15}$/i', $this->request->post['email'])) {
			$this->error['email'] = $this->language->get('error_email');
		}

		if ((utf8_strlen($this->request->post['password']) < 4) || (utf8_strlen($this->request->post['password']) > 20)) {
			$this->error['password'] = $this->language->get('error_password');
		}

		return !$this->error;
	}
    
    public function loginform() {
        $this->load->language('module/aslogin');
        
        $data['text_login'] = $this->language->get('text_login');
        $data['text_register'] = $this->language->get('text_register');
        $data['text_name'] = $this->language->get('text_name');
        $data['text_lname'] = $this->language->get('text_lname');
        $data['text_password'] = $this->language->get('text_password');
        $data['text_cfpassword'] = $this->language->get('text_cfpassword');
        $data['text_email'] = $this->language->get('text_email');
        $data['text_signup'] = $this->language->get('text_signup');
		$data['text_login'] = $this->language->get('text_login');
		$data['text_forgetpassword'] = $this->language->get('text_forgetpassword');
        
        $data['login'] = $this->url->link('module/aslogin/loginform', '', 'SSL');
        $data['register'] = $this->url->link('module/aslogin/registerform', '', 'SSL');
		$data['forgetlink'] = $this->url->link('module/aslogin/forgetform', '', 'SSL');
		
		$data['asloginformlayout'] = 0;
        
        $this->response->setOutput($this->load->view('module/aslogin', $data));
    }
	
	public function login() {
		$this->load->language('module/aslogin');
		$this->load->model('module/aslogin');
		$this->load->model('account/customer');
		
		// Login override for admin users
		if (!empty($this->request->get['token'])) {
			$this->event->trigger('pre.customer.login');

			$this->customer->logout();
			$this->cart->clear();

			unset($this->session->data['wishlist']);
			unset($this->session->data['payment_address']);
			unset($this->session->data['payment_method']);
			unset($this->session->data['payment_methods']);
			unset($this->session->data['shipping_address']);
			unset($this->session->data['shipping_method']);
			unset($this->session->data['shipping_methods']);
			unset($this->session->data['comment']);
			unset($this->session->data['order_id']);
			unset($this->session->data['coupon']);
			unset($this->session->data['reward']);
			unset($this->session->data['voucher']);
			unset($this->session->data['vouchers']);
			
			$customer_info = $this->model_account_customer->getCustomerByToken($this->request->get['token']);
			
			if ($customer_info && $this->customer->login($customer_info['email'], '', true)) {
				// Default Addresses
				$this->load->model('account/address');

				if ($this->config->get('config_tax_customer') == 'payment') {
					$this->session->data['payment_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
				}

				if ($this->config->get('config_tax_customer') == 'shipping') {
					$this->session->data['shipping_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
				}

				$this->event->trigger('post.customer.login');

				$this->response->redirect($this->url->link('account/account', '', 'SSL'));
			}
		}
		
		if ($this->customer->isLogged()) {
			$this->response->redirect($this->url->link('account/account', '', 'SSL'));
		}
		
		$this->document->setTitle($this->language->get('heading_title'));

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validatelogin()) {
			unset($this->session->data['guest']);

			// Default Shipping Address
			$this->load->model('account/address');

			if ($this->config->get('config_tax_customer') == 'payment') {
				$this->session->data['payment_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
			}

			if ($this->config->get('config_tax_customer') == 'shipping') {
				$this->session->data['shipping_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
			}

			// Add to activity log
			$this->load->model('account/activity');

			$activity_data = array(
				'customer_id' => $this->customer->getId(),
				'name'        => $this->customer->getFirstName() . ' ' . $this->customer->getLastName()
			);

			$this->model_account_activity->addActivity('login', $activity_data);
			
			// Added strpos check to pass McAfee PCI compliance test (http://forum.opencart.com/viewtopic.php?f=10&t=12043&p=151494#p151295)
			if (isset($this->request->post['redirect']) && (strpos($this->request->post['redirect'], $this->config->get('config_url')) !== false || strpos($this->request->post['redirect'], $this->config->get('config_ssl')) !== false)) {
				//$this->response->redirect(str_replace('&amp;', '&', $this->request->post['redirect']));		
				
			} else {
				$loginsuccess = 1;
				$data['code'] = 'aslogin';
				$data['key_redirect'] = 'aslogin_redirect';
		
				$redirectstatus = $this->model_module_aslogin->checkRedirectStatus($data);
				
				echo json_encode( array('loginsuccess'=>$loginsuccess, 'redirectstatus'=>$redirectstatus['value']));
			}
		} else {
			$loginsuccess = 0;
			echo json_encode( array('loginsuccess'=>$loginsuccess));
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} else {
			$data['email'] = '';
		}

		if (isset($this->request->post['password'])) {
			$data['password'] = $this->request->post['password'];
		} else {
			$data['password'] = '';
		}

    }
	
	protected function validatelogin() {
		$this->event->trigger('pre.customer.login');
		$this->load->model('account/customer');
		
		// Check how many login attempts have been made.
		$login_info = $this->model_account_customer->getLoginAttempts($this->request->post['email']);

		if ($login_info && ($login_info['total'] >= $this->config->get('config_login_attempts')) && strtotime('-1 hour') < strtotime($login_info['date_modified'])) {
			$this->error['warning'] = $this->language->get('error_attempts');
		}

		// Check if customer has been approved.
		$customer_info = $this->model_account_customer->getCustomerByEmail($this->request->post['email']);

		if ($customer_info && !$customer_info['approved']) {
			$this->error['warning'] = $this->language->get('error_approved');
		}

		if (!$this->error) {
			if (!$this->customer->login($this->request->post['email'], $this->request->post['password'])) {
				$this->error['warning'] = $this->language->get('error_login');

				$this->model_account_customer->addLoginAttempt($this->request->post['email']);
			} else {
				$this->model_account_customer->deleteLoginAttempts($this->request->post['email']);

				$this->event->trigger('post.customer.login');
			}
		}

		return !$this->error;
	}
	
	public function forgetform() {
        $this->load->language('module/aslogin');
        
        $data['text_login'] = $this->language->get('text_login');
        $data['text_register'] = $this->language->get('text_register');
        $data['text_email'] = $this->language->get('text_email');
		$data['text_forgettext'] = $this->language->get('text_forgettext');
        
        $data['login'] = $this->url->link('module/aslogin/loginform', '', 'SSL');
        $data['register'] = $this->url->link('module/aslogin/registerform', '', 'SSL');
		$data['forgetlink'] = $this->url->link('module/aslogin/forgetform', '', 'SSL');
		
		$data['asloginformlayout'] = 2;
        
        $this->response->setOutput($this->load->view('module/aslogin', $data));
    }
	
	public function forget() {
		$this->load->language('module/aslogin');
                $this->load->model('setting/setting');
		
		$data['text_forgetmail'] = $this->language->get('text_forgetmail');
		$data['text_forgetmailfail'] = $this->language->get('text_forgetmailfail');
		
		if ($this->customer->isLogged()) {
			$this->response->redirect($this->url->link('account/account', '', 'SSL'));
		}

		$this->load->language('account/forgotten');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('account/customer');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateforget()) {
			$this->load->language('mail/forgotten');

			$password = substr(sha1(uniqid(mt_rand(), true)), 0, 10);

			$this->model_account_customer->editPassword($this->request->post['email'], $password);

			$subject = sprintf($this->language->get('text_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));

			$message  = sprintf($this->language->get('text_greeting'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8')) . "\n\n";
			$message .= $this->language->get('text_password') . "\n\n";
			$message .= $password;

                        $siteurl = HTTP_SERVER;
		        $siteurlex = explode('.',$siteurl);
		        $siteurlname = explode('//',$siteurlex[0]);
                        $data['email'] = $this->request->post['email'];
		        //**********************Get aslogin Setting**************************************
		        $code = 'aslogin';
		        $msetting = $this->model_setting_setting->getSetting($code);
		        //*******************Get aslogin Setting End*************************************
		        $data['weemail'] = $msetting['aslogin_weemail'];
		        $data['emessgae'] = $msetting['aslogin_emailmesssage'];
		        $data['twitter'] = $msetting['aslogin_tname'];
		        $data['facebook'] = $msetting['aslogin_fbname'];
		        $data['googleplus'] = $msetting['aslogin_gname'];

                        $getlogo = $this->model_setting_setting->getSetting($code = 'config');
				
		        $data['logo'] = $getlogo['config_logo'];

		        //**********************Forget Password Mail Start**************************************
                        $to = $data['email'];					
			$subject = 'New Password for '.$siteurlname[1].'.';
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$headers .= 'From: <'.$siteurlname[1].'>' . "\r\n";
			$message = '
					<html>
					<head>
						<title></title>
					</head>
					<body style="margin:0; font-family: sans-serif; background: #e6e6e6;">
						<div style="width: 91%;border: 15px solid #F1F1F1;float: left;">
							<div style="float: left; width: 100%; text-align: center; background: #fff;">
								<img src="'.$siteurl.'image/'.$data['logo'].'" style="width: 30%; padding: 2%;">
							</div>
							<div style="float: left; width: 100%; background: #f1f1f1;">
								<div style="float: left; width: 30%; text-align: center;">
									<div style="background: #4a5686; float: left; width: 100%; padding-top: 16%; padding-bottom: 16%;">
										<img src="'.$siteurl.'image/catalog/email.png" style="width: 30%; padding: 9% 3% 3% 3%;">
										<p style="color: #fff">NEW PASSWORD</p>
									</div>
									
								</div>
								<div style="float: left; width: 70%;">                   
									<div style="float: left; width: 92%; text-align: center; padding: 4%; font-family: cursive;">
										<p style="font-weight: 600;">WELCOME CUSTOMER</p>
										<p style="margin-bottom: 5%;">'.$message.'</p>
									</div>
								</div>
								<div style="float: left; width: 100%; padding: 1% 0% 1% 0%;  background: #fff; text-align: center;">
									<div style="width: 30%; float: left;">
										<a  href="'.$data['facebook'].'"><img src="'.$siteurl.'image/catalog/fb.png" style="width: 20%;"></a>
										<a  href="'.$data['googleplus'].'"><img src="'.$siteurl.'image/catalog/gplus.png" style="width: 20%;"></a>
										<a  href="'.$data['twitter'].'"><img src="'.$siteurl.'image/catalog/twi.png" style="width: 20%;"></a>
									</div>
									<div style="width: 70%; float: left;font-family: cursive;">
										<p style="margin: 0; font-size: 13px; font-weight: 500;">We would love to hear from you. Just write us at <a href="'.$siteurl.'index.php?route=information/contact">'.$siteurlname[1].'</a></p>
										<p style="font-size: 13px; margin-top: 1%; font-weight: 600;">Copyright (c) '.$siteurlname[1].'</p>
									</div>
								</div>
							</div>   
						</div>
					</body>
				</html>
			';
			mail($to, $subject, $message, $headers);
		        //**********************Forget Password Mail End**************************************

			$this->session->data['success'] = $this->language->get('text_success');

			// Add to activity log
			$customer_info = $this->model_account_customer->getCustomerByEmail($this->request->post['email']);

			if ($customer_info) {
				$this->load->model('account/activity');

				$activity_data = array(
					'customer_id' => $customer_info['customer_id'],
					'name'        => $customer_info['firstname'] . ' ' . $customer_info['lastname']
				);

				$this->model_account_activity->addActivity('forgotten', $activity_data);
			}
			echo($data['text_forgetmail']);
		} else {
			echo($data['text_forgetmailfail']);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

	}
	
	protected function validateforget() {
		if (!isset($this->request->post['email'])) {
			$this->error['warning'] = $this->language->get('error_email');
		} elseif (!$this->model_account_customer->getTotalCustomersByEmail($this->request->post['email'])) {
			$this->error['warning'] = $this->language->get('error_email');
		}

		return !$this->error;
	}
}
