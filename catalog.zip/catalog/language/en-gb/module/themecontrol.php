<?php
$_['text_tax']      = 'Ex Tax:';
$_['text_sale'] = 'Sale';
$_['text_new'] = 'New';
$_['text_sale_detail'] = 'Save: %s';
$_['text_contact_us'] = 'Contact Us';

$_['text_color_tools'] = 'Live Theme Editor';
$_['text_selectors']   = 'Layout Selectors';
$_['text_elements']   = 'Layout Elements';


$_['text_sidebar_left'] = 'Sidebar Left';
$_['text_sidebar_right'] = 'Sidebar Right';

$_['text_about_us'] = 'About Us';

$_['quick_view']      = 'Quick View';
$_['txt_product_zoom']      = 'Pproduct Zoom';
$_['text_tax']      = 'Ex Tax:';
$_['text_item']      = 'item';
$_['text_items']      = 'items';
$_['text_review']      = 'Reviews';

$_['text_setting']      = 'Setting';
$_['text_account_skin']      = 'account';
$_['text_account_2kin']      = 'account';

$_['text_latest'] = 'Sale';
$_['text_link'] = 'Read more';

$_['text_days'] = 'Days';
$_['text_hours'] = 'hours';
$_['text_minutes'] = 'Mins';
$_['text_seconds'] = 'Secs';
$_['text_featured'] = 'Featured';
$_['text_bestseller'] = 'Bestseller';
$_['text_special'] = 'Special';
$_['text_mostviewed'] = 'Mostviewed';
$_['text_heading_title'] = 'My cart';
$_['text_all_category']  = 'Vetical menu';
$_['text_dont_miss']  = 'Donts miss';
$_['text_finish'] = 'Expired';
$_['text_list']  = 'List';
$_['text_grid']  = 'Grid';

//lexus kitchen
$_['shop_by_categories']  = 'Vertical menu';
$_['text_latest']  = 'Latest';
$_['text_viewmore']  = 'View More';
$_['text_off'] = 'Off';
?>