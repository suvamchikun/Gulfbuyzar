<?php

// Text
$_['text_title'] = 'طرق الشحن';
$_['text_weight'] = 'الوزن :'; 
