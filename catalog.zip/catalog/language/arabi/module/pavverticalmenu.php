<?php
$_['text_catalog_menu'] = 'التصنيفات';
?>
