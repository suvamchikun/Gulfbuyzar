<?php
// Heading
$_['heading_title'] = 'أقسام الموقع';
