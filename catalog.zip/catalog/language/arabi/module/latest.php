<?php

// Heading 
$_['heading_title'] = 'أضيف مؤخراً';

// Text
$_['text_tax']      = 'Ex Tax:';