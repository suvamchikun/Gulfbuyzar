<?php
// Text
$_['text_reward']   = 'نقاط المكافآت (%s)';
$_['text_order_id'] = 'رقم الطلب : #%s';
