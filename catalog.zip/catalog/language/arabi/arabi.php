<?php
// Locale
$_['code']                  = 'ar';
$_['direction']             = 'rtl';
$_['date_format_short']     = 'Y/m/d';
$_['date_format_long']      = 'l dS F Y';
$_['time_format']           = 'h:i:s A';
$_['datetime_format']       = 'd/m/Y H:i:s';
$_['decimal_point']         = '.';
$_['thousand_point']        = ',';

// Text
$_['text_home']             = 'الرئيسية';
$_['text_yes']              = 'نعم';
$_['text_no']               = 'لا';
$_['text_none']             = ' --- لا يوجد --- ';
$_['text_select']           = ' --- الرجاء الاختيار --- ';
$_['text_all_zones']        = 'جميع الاقسام';
$_['text_pagination']         = 'عرض %d الى %d من %d (%d صفحات)';
$_['text_loading']          = 'Loading...';

// Buttons
$_['button_address_add']    = 'Add Address';
$_['button_back']           = 'رجوع';
$_['button_continue']       = 'متابعة';
$_['button_cart']           = 'اضافة للسلة';
$_['button_cancel']         = 'Cancel';
$_['button_compare']        = 'Compare this Product';
$_['button_wishlist']       = 'Add to Wish List';
$_['button_checkout']       = 'انهاء الطلب';
$_['button_confirm']        = 'تأكيد الطلب';
$_['button_coupon']         = 'اعتمد التخفيض';
$_['button_delete']         = 'حذف';
$_['button_download']       = 'تنزيل';
$_['button_edit']           = 'تحرير';
$_['button_filter']         = 'بحث محسن';
$_['button_new_address']    = 'عناوين جديدة';
$_['button_change_address'] = 'تغيير العناوين';
$_['button_reviews']        = 'Reviews';
$_['button_write']          = 'Write Review';
$_['button_login']          = 'دخول';
$_['button_update']         = 'تحديث الكمية';
$_['button_remove']         = 'حذف';
$_['button_reorder']        = 'إعادة طلب';
$_['button_return']         = 'إرجاع الطلب';
$_['button_shopping']       = 'متابعة';
$_['button_search']         = 'بحث';
$_['button_shipping']       = 'اعتمد الشحن';
$_['button_submit']         = 'Submit';
$_['button_guest']          = 'Guest Checkout';
$_['button_view']           = 'عرض';
$_['button_voucher']        = 'أرسل';
$_['button_upload']         = 'رفع الملف';
$_['button_reward']         = 'اعتمد النقاط';
$_['button_quote']          = 'أرسل';
$_['button_list']           = 'List';
$_['button_grid']           = 'Grid';
$_['button_map']            = 'View Google Map';

// Error
$_['error_exception']       = 'Error Code(%s): %s in %s on line %s';
$_['error_upload_1']        = 'Warning: The uploaded file exceeds the upload_max_filesize directive in php.ini!';
$_['error_upload_2']        = 'Warning: The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form!';
$_['error_upload_3']        = 'Warning: The uploaded file was only partially uploaded!';
$_['error_upload_4']        = 'Warning: No file was uploaded!';
$_['error_upload_6']        = 'Warning: Missing a temporary folder!';
$_['error_upload_7']        = 'Warning: Failed to write file to disk!';
$_['error_upload_8']        = 'Warning: File upload stopped by extension!';
$_['error_upload_999']      = 'Warning: No error code available!';
