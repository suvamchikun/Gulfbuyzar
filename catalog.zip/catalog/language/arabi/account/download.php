<?php
// Heading
$_['heading_title']     = 'Account Downloads';

// Text
$_['text_account']      = 'حساب';
$_['text_downloads']    = 'التنزيلات';
$_['text_empty']        = 'هل لم تصدر أي أوامر للتنزيل السابقة !';

// Column
$_['column_order_id']   = 'ترتيب ID';
$_['column_name']       = 'اسم';
$_['column_size']       = 'حجم';
$_['column_date_added'] = 'تاريخ الاضافة';