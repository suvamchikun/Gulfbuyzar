<?php
// Heading
$_['heading_title']    = 'Newsletter Subscription';

// Text
$_['text_account']     = 'الحساب';
$_['text_newsletter']  = 'القائمة البريدية';
$_['text_success']     = 'تم التعديل !';

// Entry
$_['entry_newsletter'] = 'اشترك:';
