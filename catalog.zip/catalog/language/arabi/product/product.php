<?php


// Text
$_['text_search']         = 'بحث';
$_['text_brand']          = 'الشركة';
$_['text_manufacturer']   = 'الشركة :';
$_['text_model']          = 'النوع :';
$_['text_reward']         = 'نقاط المكافآت :'; 
$_['text_points']         = 'السعر بنقاط المكافآت :';
$_['text_stock']          = 'حالة التوفر :';
$_['text_instock']        = 'متوفر';
$_['text_tax']            = 'الضريبة :'; 
$_['text_discount']       = '%s أو أكثر %s';
$_['text_option']         = 'الخيارات المتاحة:';
$_['text_minimum']                            = 'This product has a minimum quantity of %s';
$_['text_reviews']                            = '%s reviews';
$_['text_write']                              = 'Write a review';
$_['text_login']                              = 'Please <a href="%s">login</a> or <a href="%s">register</a> to review';
$_['text_no_reviews']                         = 'There are no reviews for this product.';
$_['text_note']                               = '<span class="text-danger">Note:</span> HTML is not translated!';
$_['text_success']                            = 'Thank you for your review. It has been submitted to the webmaster for approval.';
$_['text_related']                            = 'Related Products';
$_['text_tags']                               = 'Tags:';
$_['text_error']                              = 'Product not found!';
$_['text_payment_recurring']                    = 'Payment Profiles';
$_['text_trial_description']                  = '%s every %d %s(s) for %d payment(s) then';
$_['text_payment_description']                = '%s every %d %s(s) for %d payment(s)';
$_['text_payment_until_canceled_description'] = '%s every %d %s(s) until canceled';
$_['text_day']                                = 'day';
$_['text_week']                               = 'week';
$_['text_semi_month']                         = 'half-month';
$_['text_month']                              = 'month';
$_['text_year']                               = 'year';

// Entry
$_['entry_qty']                               = 'Qty';
$_['entry_name']          = 'الاسم:';
$_['entry_review']        = 'اضافة تعليق:';
$_['entry_rating']        = 'التقييم:';
$_['entry_good']          = 'ممتاز';
$_['entry_bad']           = 'رديء';
$_['entry_captcha']       = 'قم بإدخال رمز التحقق :';

// Tabs
$_['tab_description']     = 'تفاصيل';
$_['tab_attribute']       = 'المواصفات';
$_['tab_review']          = 'التقييمات (%s)';

// Error
$_['error_name']          = 'تحذير : الاسم يجب أن يكون أكثر من 3 وأقل من 25 رمزاً !';
$_['error_text']          = 'تحذير : النص يجب أن يكون أكثر من 25 وأقل من 1000 رمز !';
$_['error_rating']        = 'تحذير : الرجاء اختيار استعراض التعليق !';
$_['error_captcha']       = 'تحذير : رمز التحقق لا يتطابق مع الصورة !';
