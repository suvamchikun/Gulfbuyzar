<?php
// Text
$_['text_subject']  = '%s - شكراً لتسجيلك معنا';
$_['text_welcome']  = 'مرحباً بك وشكرا لتسجيلك في %s!';
$_['text_login']    = 'لقد تم انشاء حسابك ويمكنك الان تسجيل الدخول باسم بريدك الالكتروني وكلمة المرور بزيارة موقعنا على الرابط التالي :';
$_['text_approval'] = 'يجب الموافقة أولاً على استكمال انشاء حسابك من ادارة الموقع. وبعد ذلك يمكنك تسجيل الدخول باسم بريدك الالكتروني وكلمة المرور بزيارة موقعنا على الرابط التالي :';
$_['text_services'] = 'بعد تسجيل الدخول, سوف تتمكن من الحصول على الخدمات الاخرى في موقعنا مثل مراجعة الطلبات السابقة وطباعة الفواتير وتعديل المعلومات الخاصة بك .';
$_['text_thanks']   = 'شكراً لك,';
$_['text_new_customer']   = 'New customer';
$_['text_signup']         = 'A new customer has signed up:';
$_['text_website']        = 'Web Site:';
$_['text_customer_group'] = 'Customer Group:';
$_['text_firstname']      = 'First Name:';
$_['text_lastname']       = 'Last Name:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Telephone:';