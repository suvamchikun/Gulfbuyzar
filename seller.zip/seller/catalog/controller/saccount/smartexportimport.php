<?php 
class ControllerSaccountSmartExportImport extends Controller { 
	private $error = array();
	
	public function index() {
	if (!$this->seller->isLogged()) {
	  		$this->session->data['redirect'] = $this->url->link('saccount/smartexportimport', '', 'SSL');
	  
	  		$this->response->redirect($this->url->link('saccount/login', '', 'SSL'));
    	} 
		$this->load->language('saccount/smartexportimport');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('saccount/smartexportimport');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {
			if ((isset( $this->request->files['upload'] )) && (is_uploaded_file($this->request->files['upload']['tmp_name']))) {
				$file = $this->request->files['upload']['tmp_name'];
				if ($this->model_saccount_smartexportimport->upload($file)===TRUE) {
					$wrongmodels = "";
					$wrongmanufact = "";
					if(isset($this->session->data['wrongmodels'])){
						 $msg = implode(',',$this->session->data['wrongmodels']);	 
						 $wrongmodels = "Model name must be unique. ".count($this->session->data['wrongmodels'])." Product(s) having model number ".$msg." already exist so can't be added.";
						 $this->error['warning'] = $wrongmodels;
					}
					
					

					if(empty($wrongmodels))
					{
						$this->session->data['success'] = $this->language->get('text_success');
					}
					unset($this->session->data['wrongmodels']);
					
					//$this->response->redirect($this->url->link('saccount/smartexportimport', '', 'SSL'));
				}
				else {
					$this->error['warning'] = $this->language->get('error_upload');
				}
			}
		}

		if (!empty($this->session->data['export_error']['errstr'])) {
			$this->error['warning'] = $this->session->data['export_error']['errstr'];
			if (!empty($this->session->data['export_nochange'])) {
				$this->error['warning'] .= '<br />'.$this->language->get( 'text_nochange' );
			}
			$this->error['warning'] .= '<br />'.$this->language->get( 'text_log_details' );
		}
		unset($this->session->data['export_error']);
		unset($this->session->data['export_nochange']);
		
		$minProductId = $this->model_saccount_smartexportimport->getMinproduct_id();
		$maxProductId = $this->model_saccount_smartexportimport->getMaxproduct_id();
		$countProduct = $this->model_saccount_smartexportimport->getCountproduct();
		
		$data['min_product_id'] = $minProductId;
		$data['max_product_id'] = $maxProductId;
		$data['count_product'] = $countProduct;

		$data['heading_title'] = $this->language->get('heading_title');
		$data['entry_restore'] = $this->language->get('entry_restore');
		$data['entry_description'] = $this->language->get('entry_description');
		$data['button_import'] = $this->language->get('button_import');
		$data['button_export'] = $this->language->get('button_export');

		$data['entry_exportway_sel'] = $this->language->get('entry_exportway_sel');
		$data['entry_start_id'] = $this->language->get('entry_start_id');
		$data['entry_end_id'] = $this->language->get('entry_end_id');
		$data['entry_start_index'] = $this->language->get('entry_start_index');
		$data['entry_end_index'] = $this->language->get('entry_end_index');
		$data['button_export_pid'] = $this->language->get('button_export_pid');
		$data['button_export_page'] = $this->language->get('button_export_page');

		$data['tab_general'] = $this->language->get('tab_general');
		$data['error_select_file'] = $this->language->get('error_select_file');
		$data['error_post_max_size'] = str_replace( '%1', ini_get('post_max_size'), $this->language->get('error_post_max_size') );
		$data['error_upload_max_filesize'] = str_replace( '%1', ini_get('upload_max_filesize'), $this->language->get('error_upload_max_filesize') );
		$data['error_pid_no_data'] = $this->language->get('error_pid_no_data');
		$data['error_page_no_data'] = $this->language->get('error_page_no_data');
		$data['error_param_not_number'] = $this->language->get('error_param_not_number');

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', '', 'SSL'),
			'separator' => FALSE
		);
		
		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_acount'),
			'href'      => $this->url->link('saccount/account', '', 'SSL'),
			'separator' => FALSE
		);

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('saccount/smartexportimport', '', 'SSL'),
			'separator' => ' :: '
		);
		
		
		$data['format'] = HTTP_SERVER.'formats.xls';
		
		
		$data['action'] = $this->url->link('saccount/smartexportimport', '', 'SSL');
		$data['export'] = $this->url->link('saccount/smartexportimport/download', '', 'SSL');
		$data['post_max_size'] = $this->return_bytes( ini_get('post_max_size') );
		$data['upload_max_filesize'] = $this->return_bytes( ini_get('upload_max_filesize') );
		
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('saccount/smartexportimport', $data));
	}


	function return_bytes($val)
	{
		$val = trim($val);
	
		switch (strtolower(substr($val, -1)))
		{
			case 'm': $val = (int)substr($val, 0, -1) * 1048576; break;
			case 'k': $val = (int)substr($val, 0, -1) * 1024; break;
			case 'g': $val = (int)substr($val, 0, -1) * 1073741824; break;
			case 'b':
				switch (strtolower(substr($val, -2, 1)))
				{
					case 'm': $val = (int)substr($val, 0, -2) * 1048576; break;
					case 'k': $val = (int)substr($val, 0, -2) * 1024; break;
					case 'g': $val = (int)substr($val, 0, -2) * 1073741824; break;
					default : break;
				} break;
			default: break;
		}
		return $val;
	}


	public function download() {
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {
			
			if (isset( $this->request->post['exportway'] )) {
				$exportway = $this->request->post['exportway'];
			}
			if (isset( $this->request->post['min'] )) {
				$min = $this->request->post['min'];
			}
			if (isset( $this->request->post['max'] )) {
				$max = $this->request->post['max'];
			}
			// send the categories, products and options as a spreadsheet file
			$this->load->model('saccount/smartexportimport');
			switch($exportway) {
				case 'pid':
					$this->model_saccount_smartexportimport->download(NULL, NULL, $min, $max);
					break;
				case 'page':
					$this->model_saccount_smartexportimport->download($min*($max-1-1), $min, NULL, NULL); //minΪÿ����С��max-1Ϊ��ǰ�����ڼ�������Ϊ��ҳ���Ͻ��з�������ʱ��ǰ���Զ���1�����ύ����ǰ���ʼ�1���ύ�����ݴ��˸�1��������Ҫ������
					break;
				default:
					break;
			}
			$this->response->redirect($this->url->link('saccount/smartexportimport', '', 'SSL'));

		} else {

			// return a permission error page
			return $this->forward('error/permission');
		}
	}


	private function validate() {
		
		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
}
?>