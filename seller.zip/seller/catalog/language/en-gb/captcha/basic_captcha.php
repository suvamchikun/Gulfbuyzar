<?php
// Text
$_['text_captcha'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Enter the code in the box below';

// Error
$_['error_captcha'] = 'Verification code does not match the image!';
