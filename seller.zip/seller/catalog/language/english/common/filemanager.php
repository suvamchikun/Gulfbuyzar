<?php
// Heading
$_['heading_title']    = 'Image Manager';

// Text
$_['text_uploaded']    = 'Success: Your file has been uploaded!';
$_['text_directory']   = 'Success: Directory created!';
$_['text_delete']      = 'Success: Your file or directory has been deleted!';

// Entry
$_['entry_search']     = 'Search..';
$_['entry_folder']     = 'Folder Name';

// Button
$_['button_insert']                 = 'Add New';
$_['button_delete']                 = 'Delete';
$_['button_save']                   = 'Save';
$_['button_cancel']                 = 'Cancel';
$_['button_cancel_recurring']       = 'Cancel Recurring Payments';
$_['button_continue']               = 'Continue';
$_['button_clear']                  = 'Clear';
$_['button_close']                  = 'Close';
$_['button_enable']                 = 'Enable';
$_['button_disable']                = 'Disable';
$_['button_filter']                 = 'Filter';
$_['button_send']                   = 'Send';
$_['button_edit']                   = 'Edit';
$_['button_copy']                   = 'Copy';
$_['button_back']                   = 'Back';
$_['button_remove']                 = 'Remove';
$_['button_refresh']                = 'Refresh';

$_['button_parent']                 = 'Parent';
$_['button_folder']                 = 'New Folder';
$_['button_search']                 = 'Search';
$_['button_view']                   = 'View';
$_['button_install']                = 'Install';
$_['button_uninstall']              = 'Uninstall';
$_['button_link']                   = 'Link';
$_['button_shipping']               = 'Apply Shipping Method';
$_['button_payment']                = 'Apply Payment Method';
$_['button_coupon']                 = 'Apply Coupon';
$_['button_voucher']                = 'Apply Voucher';
$_['button_reward']                 = 'Apply Points';

// Error
$_['error_permission'] = 'Warning: Permission Denied!';
$_['error_filename']   = 'Warning: Filename must be a between 3 and 255!';
$_['error_folder']     = 'Warning: Folder name must be a between 3 and 255!';
$_['error_exists']     = 'Warning: A file or directory with the same name already exists!';
$_['error_directory']  = 'Warning: Directory does not exist!';
$_['error_filetype']   = 'Warning: Incorrect file type!';
$_['error_upload']     = 'Warning: File could not be uploaded for an unknown reason!';
$_['error_delete']     = 'Warning: You can not delete this directory!';